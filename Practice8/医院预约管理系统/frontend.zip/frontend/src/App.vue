<template>
	<div id="app">
    <router-view />
    <!-- <div style="position:fixed;text-align:center;bottom:0;margin:0 auto;width:100%;color: #5c6b77">
      <a target="_blank" style="color: #5c6b77" href="http://www.beian.miit.gov.cn">备案号</a>
    </div> -->
	</div>
</template>

<script>
  export default{
    name: 'APP'
  }
</script>
