module.exports = {
	NODE_ENV: '"production"',
  ENV_CONFIG: '"dep"',
  BASE_API: '"http://localhost:8081/"'
}
