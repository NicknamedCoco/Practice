const uploadPath = process.env.BASE_API + 'adminApi/common/file'
export { uploadPath }
